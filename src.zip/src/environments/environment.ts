// src/environments/environment.ts
// Used during: ng serve (development)

export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/api'
};
